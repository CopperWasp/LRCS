step-1: install xampp (selection of apache, mysql, php mandatory) (stop any mysql services if already are running)
step-2: open xampp control panel and start apache and mysql services
step-3: import the database (.sql) file using any mysql import wizard (mysql workbench is easy to use)
step-4: update the password of root to 'creative01'
step-5: copy the code foler 'LRCS' to ./xampp/htdocs/
step-6: on any web-browser open "http://localhost/LRCS/"